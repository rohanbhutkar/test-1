import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class processing_testing extends PApplet {

boolean title;
boolean marketing;
boolean buisnessAdministrationCore;
boolean finance;
boolean hospitality;
boolean financialLiteracy;
boolean buisnessAdmin;
boolean fontType;
int questionNum;
int answerNum;
float rectx;
float recty;
boolean finalsection;
String answerFinal;
boolean answered;
boolean read;
boolean mouseClicked;
boolean correct;
int correctAns;
boolean timed;
boolean menu;
int m; 
int starttime;
int seconds;
int min;
String testTest;
String testAnswers;
String testExplanation;
int seconds60;
int second60;
boolean questions;
PImage logo;
PImage diamond;
PImage pflGraph;
PImage bsmGraph;
public void setup() {
  
  background(0xff223B83);
  marketing = false;
  buisnessAdministrationCore = false;
  finance = false;
  hospitality = false;
  financialLiteracy = false;
  fontType = false;
  questionNum = 0;
  answerNum = 0;
  rectx = -300;
  recty = -300;
  finalsection = false;
  answered = false;
  read = false;
  mouseClicked = false;
  correct = false;
  correctAns = 0;
  second60 = 60;
  questions = false;
  menu = false;
  logo = loadImage("JFSS Athletics Logo.png");
  diamond = loadImage ("deca.png");
  pflGraph = loadImage ("2015 pfl graph.png");
  bsmGraph = loadImage ("BuisnessManagement.PNG");
  buisnessAdmin=false;
}
public void draw() {
  startMenu();
}
public void startMenu() {
  background(0xff223B83);
  textAlign(CENTER, CENTER);
  textSize(45);
  fill(255);
  text("DECA Practice Exam Software", width/2, height/4);
  text("START", width/2, height/2);
  imageMode(CENTER);
  image(logo, 3*width/16, height/2);
  diamond.resize(200, 200);
  image(diamond, 13*width/16, height/2);
  textSize(15);
  fill(175);
  text("Software Created by Rohan Bhutkar for John Fraser Secondary School's DECA Chapter", width/2, height-50);
  if (title) {
    time();
  }
  if (mousePressed) {
    if (mouseX>width/4 && mouseX< 3*width/4 && mouseY>height/2-30 && mouseY <height/2+30) {
      title = true;
    }
    mousePressed=false;
  }
}
public void time() {
  background(0xff223B83);
  textAlign(CENTER, CENTER);
  textSize(15);
  fill(175);
  text("Software Created by Rohan Bhutkar for John Fraser Secondary School's DECA Chapter", width/2, height-50);
  textSize(30);
  fill(255);
  text("Choose practice or test", width/2, height/2-100);
  textSize(20);
  text("Practice", width/2, height/2);
  text("Test", width/2, height/2+50);
  image(logo, 3*width/16, height/2);
  image(diamond, 13*width/16, height/2);
  if (menu) {
    if (mousePressed&&mouseX<100&&mouseX>0&&mouseY<60&&mouseY>0) {
      setup();
    }
    mainMenu();
    textSize(15);
    fill(255);
    stroke(255);
    beginShape();
    vertex(30, 40);
    vertex(50, 20);
    vertex(50, 30);
    vertex(100, 30);
    vertex(100, 50);
    vertex(50, 50);
    vertex(50, 60);
    endShape();
    fill(0);
    text("Menu", 70, 37);
  }
  if (mousePressed&&mouseX>width/4 && mouseX< 3*width/4 && mouseY>height/2-20 && mouseY <height/2+20) {
    timed = false;
    menu = true;
    mousePressed = false;
  }
  if (mousePressed&&mouseX>width/4 && mouseX< 3*width/4 && mouseY>height/2+30 && mouseY <height/2+70) {
    timed = true;
    menu = true;
    mousePressed = false;
  }
}
public void mainMenu() {
  background(0xff223B83);
  textSize(30);
  textAlign(CENTER, CENTER);
  fill(255);
  text("Choose your catergory", width/2, height/8);
  textSize(15);
  text("Marketing", width/2, height/4);
  text("Business Administration Core", width/2, 3*height/8);
  text("Finance", width/2, height/2);
  text("Hospitality", width/2, 5*height/8);
  text("Financial Literacy", width/2, 6*height/8);
  text("Buisness Management", width/2, 7*height/8);
  if (mousePressed) {
    if (mouseX>width/4 && mouseX <3*width/4 && mouseY>height/4-10 && mouseY <height/4+10) {
      marketing = true;
      starttime=millis();
    }
    if (mouseX>width/4 && mouseX <3*width/4 && mouseY>3*height/8-10 && mouseY <3*height/8+10) {
      buisnessAdministrationCore = true;
      starttime=millis();
    }
    if (mouseX>width/4 && mouseX <3*width/4 && mouseY>height/2-10 && mouseY <height/2+10) {
      finance = true;
      starttime=millis();
    }
    if (mouseX>width/4 && mouseX <3*width/4 && mouseY>5*height/8-10 && mouseY <5*height/8+10) {
      hospitality = true;
      starttime=millis();
    }
    if (mouseX>width/4 && mouseX <3*width/4 && mouseY>6*height/8-10 && mouseY <6*height/8+10) {
      financialLiteracy = true;
      starttime=millis();
    }
    if (mouseX>width/4 && mouseX <3*width/4 && mouseY>7*height/8-10 && mouseY <7*height/8+10) {
      buisnessAdmin = true;
      starttime=millis();
    }
  }
  if (marketing) {
    marketing();
  }
  if (buisnessAdministrationCore) {
    buisnessAdministrationCore();
  }
  if (finance) {
    finance();
  }
  if (hospitality) {
    hospitality();
  }
  if (financialLiteracy) {
    financialLiteracy();
  }
  if (buisnessAdmin) {
    buisnessAdmin();
  }
}

public void questions() {
  textSize(15);
  background(0xff223B83);
  if (questionNum == 195 && testTest== "2015 pfl provincials test.txt") {
    image(pflGraph, width/2, height/2);
  }
  bsmGraph.resize(width/3, height/8);
  if (questionNum==385&&testTest=="2013 BA Provs Test.txt") {
    image(bsmGraph, width/2, 4*height/10);
  }
  stopwatch();
  String[] test =  loadStrings (testTest);
  String[] answers =  loadStrings (testAnswers);
  String[] explanation = loadStrings (testExplanation);
  //question
  text(test [questionNum], width/2, height/4, width-50, height);
  rectMode(RADIUS);
  text(test [questionNum+1], width/4, height/2, width/4-10, height/6);
  text(test [questionNum+2], 3*width/4, height/2, width/4-10, height/6);
  text(test [questionNum+3], width/4, 3*height/4, width/4-10, height/6);
  text(test [questionNum+4], 3*width/4, 3*height/4, width/4-10, height/6);
  stroke(0xff0BC7D6);
  noFill();
  rectMode(CENTER);
  rect(rectx, recty, 500, 50);
  stroke(255);
  rect(width-110, height-60, 200, 50);
  fill(255);
  text("SUBMIT", width-110, height-60);
  text(75-min, 40, width-40);

  if (mouseClicked) {
    if (mouseX>0 && mouseX <width/2 && mouseY>height/2-10 && mouseY <height/2+10) {
      answerFinal = "A";
      rectx = width/4;
      recty = height/2;
    }
    if (mouseX>width/2 && mouseX <width && mouseY>height/2-10 && mouseY <height/2+10) {
      answerFinal = "B";
      rectx = 3*width/4;
      recty = height/2;
    }    
    if (mouseX>0 && mouseX <width/2 && mouseY>3*height/4-10 && mouseY <3*height/4+10) {
      answerFinal = "C";
      rectx = width/4;
      recty = 3*height/4;
    }    
    if (mouseX>width/2 && mouseX <width && mouseY>3*height/4-10&& mouseY <3*height/4+10) {
      answerFinal = "D";
      rectx = 3*width/4;
      recty = 3*height/4;
    }
    if (mouseX>width-300 && mouseX <width && mouseY>height-100&& mouseY <height) {
      if (answers[answerNum].equals(answerFinal) == true) {
        correct = true;
      } else {
        read = true;
      }
    }
  }
  if (correct) {
    if (timed) {
      answered = true;
      correct = false;
      rectx = -300;
      recty = -300;
    } else {
      background(0xff223B83);
      fill(0, 255, 0);
      textSize(64);
      text("Correct", width/2, height/2);
      rectx = -300;
      recty = -300;
      noFill();
      stroke(255);
      rect(110, height-60, 200, 50);
      textSize(15);
      fill(255);
      text("NEXT", 110, height-60);
      if (mouseClicked == true&&mouseX>0&&mouseX<300&&mouseY<height&&mouseY>height-100) {
        correct = false;
        rectx = -300;
        recty = -300;
        correctAns++;
        answered = true;
      }
    }
  }
  if (read) {
    if (timed) {
      answered = true;
      read = false;
      rectx = -300;
      recty = -300;
    } else {
      background(0xff223B83);
      fill(255, 0, 0);
      textSize(64); 
      text("Wrong", width/2, 100);
      textSize(15);
      fill(255);
      text(test[questionNum], width/2, height/2-100, width-20, height-20);
      text(explanation[answerNum], width/2, height/2+100, width-20, height-20);
      noFill();
      stroke(255);
      rect(110, height-60, 200, 50);
      text("NEXT", 110, height-60);
      if (mouseClicked == true&&mouseX>0&&mouseX<300&&mouseY<height&&mouseY>height-100) {
        read = false;
        rectx = -300;
        recty = -300;
        answered = true;
      }
    }
  }
  mouseClicked = false;
  if (answered) {
    questionNum+=5;
    answerNum++;
    answered = false;
  }
  if (answerNum >=100) {
    finalsection = true;
  }
  if (finalsection) {
    finalpart();
  }
  stopwatch();
}
public void mouseClicked() {
  mouseClicked = true;
}
public void finalpart() {
  timed = false;
  answerNum = 0;
  questionNum = 0;
  background(0xff223B83);
  text("you scored        out of 100", width/2, height/2);
  text(str(correctAns), width/2, height/2);
  noFill();
  stroke(255);
  rect(110, height-60, 200, 50);
  text("Back To Main Menu", 110, height-60);
  if (mousePressed&&mouseX>0&&mouseX<300&&mouseY<height&&mouseY>height-100) {
    correctAns = 0;
    setup();
  }
}

public void stopwatch() {
  seconds60 = second60 - seconds; 
  if (seconds60 == 0) {
    second60 += 60;
  }
  m =  millis() - starttime;
  seconds =  m / 1000;
  min = seconds/60;
  if (timed) {
    text("Time Remaining", width-60, 20);
    text(74-min, width-100, 40);
    text("min", width-75, 40);
    text(seconds60, width-50, 40);
    text("sec", width-25, 40);
    if (min==75) {
      finalsection=true;
    }
  }
}
public void buisnessAdmin() {
  background(0xff223B83);
  if (mousePressed&&questions==false) {
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 2*height/16 && mouseY < 4*height/16) {
      testAnswers= "2015 BA Provs Answers.txt";
      testTest= "2015 BA Provs Test.txt";
      testExplanation = "2015 BA Provs Explanations .txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 4*height/16 && mouseY < 6*height/16) {
      testTest= "2014 BA Provs Test.txt";
      testAnswers= "2014 BA Provs Answers.txt";
      testExplanation = "2014 BA Provs Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 6*height/16 && mouseY < 8*height/16) {
      testTest= "2014 BA Provs Test2.txt";
      testAnswers= "2014 BA Provs Answers2.txt";
      testExplanation = "2014 BA Provs Explanations2.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 8*height/16 && mouseY < 10*height/16) {
      testTest= "2013 BA Provs Test.txt";
      testAnswers= "2013 BA Provs Answers.txt";
      testExplanation = "2013 BA Provs Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 10*height/16 && mouseY < 12*height/16) {
      testTest= "2013 BA Regional Test.txt";
      testAnswers= "2013 BA Regional Answers.txt";
      testExplanation = "2013 BA Regional Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 12*height/16 && mouseY < 14*height/16) {
      testTest= "2012 BA Regionals Test.txt";
      testAnswers= "2012 BA Regionals Answers.txt";
      testExplanation = "2012 BA Regionals Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 14*height/16 && mouseY < 16*height/16) {
      testTest= "2012 BA Provincials Test.txt";
      testAnswers= "2012 BA Provincials Answers.txt";
      testExplanation = "2012 BA Provincials Explanations.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 2*height/16 && mouseY < 4*height/16) {
      testTest= "2011 BA Regionals Test.txt";
      testAnswers= "2011 BA Regionals Answers.txt";
      testExplanation = "2011 BA Regionals Explanations.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 4*height/16 && mouseY < 8*height/16) {
      testTest= "2010 BA Regional Test.txt";
      testAnswers= "2010 BA Regional Answers.txt";
      testExplanation = "2010 BA Regional Explanations.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 8*height/16 && mouseY < 10*height/16) {
      testTest= "2010 BA Provs Test.txt";
      testAnswers= "2010 BA Provs Answers.txt";
      testExplanation = "2010 BA Provs Explanations.txt";
      questions = true;
    }
  }
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(30);
  text("Choose a test", width/2, height/8-30);
  textSize(15);
  text("2015 Provincial Test", width/8, 3*height/16);
  text("2014 Regional Test", width/8, 5*height/16);
  text("2014 Provincial Test", width/8, 7*height/16);
  text("2013 Provincial Test", width/8, 9*height/16);
  text("2013 Regional Test", width/8, 11*height/16);
  text("2012 Regional Test", width/8, 13*height/16);
  text("2012 Provincial Test", width/8, 15*height/16);
  text("2011 Regional Test", 3*width/8, 3*height/16);
  text("2010 Regional Test", 3*width/8, 5*height/16);
  text("2010 Provincial Test", 3*width/8, 7*height/16);


  if (questions) {
    background(0xff223B83);
    questions();
  }
}
public void finance() {
  background(0xff223B83);
  if (mousePressed&&questions==false) {
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 2*height/16 && mouseY < 4*height/16) {
      testTest= "2015_Finance_Cluster_Provincial_Exam.txt";
      testAnswers= "2015_Finance_Cluster_Provincial_Exam_Answers.txt";
      testExplanation = "2015_Finance_Cluster_Provincial_Exam_Explnations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 4*height/16 && mouseY < 6*height/16) {
      testTest= "2014_Finance_Cluster_Prov_Exam.txt";
      testAnswers= "2014_Finance_Cluster_Prov_Exam_Answers.txt";
      testExplanation = "2014_Finance_Cluster_Prov_Exam_Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 6*height/16 && mouseY < 8*height/16) {
      testTest= "2014_Finance_Cluster_District_Exam.txt";
      testAnswers= "2014_Finance_Cluster_District_Exam_Answers.txt";
      testExplanation = "2014_Finance_Cluster_District_Exam_Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 8*height/16 && mouseY < 10*height/16) {
      testTest= "2013_2014_Finance_Cluster_District_Exam.txt";
      testAnswers= "2013_2014_Finance_Cluster_District_Exam_Answers.txt";
      testExplanation = "2013_2014_Finance_Cluster_District_Exam_Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 10*height/16 && mouseY < 12*height/16) {
      testTest= "2013 ICDC Finance Cluster exam.txt";
      testAnswers= "2013 ICDC Finance Cluster exam_Answers.txt";
      testExplanation = "2013 ICDC Finance Cluster exam_Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 12*height/16 && mouseY < 14*height/16) {
      testTest= "2012_2013_Finance_Cluster_State_Exam.txt";
      testAnswers= "2012_2013_Finance_Cluster_State_Exam_Answers.txt";
      testExplanation = "2012_2013_Finance_Cluster_State_Exam_Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 14*height/16 && mouseY < 16*height/16) {
      testTest= "2012_2013_Finance_Cluster_District_Exam.txt";
      testAnswers= "2012_2013_Finance_Cluster_District_Exam_Answers.txt";
      testExplanation = "2012_2013_Finance_Cluster_District_Exam_Explanation.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 2*height/16 && mouseY < 4*height/16) {
      testTest= "2011_2012_Finance_Cluster_State_Exam.txt";
      testAnswers= "2011_2012_Finance_Cluster_State_Answers.txt";
      testExplanation = "2011_2012_Finance_Cluster_State_Explanations.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 4*height/16 && mouseY < 6*height/16) {
      testTest= "2011 Finance Cluster Exam_1047.txt";
      testAnswers= "2011 Finance Cluster Answers_1047.txt";
      testExplanation = "2011 Finance Cluster Explanations_1047.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 6*height/16 && mouseY < 8*height/16) {
      testTest= "2010 Finance Cluster Exam B10.txt";
      testAnswers= "2010 Finance Cluster Answers B10.txt";
      testExplanation = "2010 Finance Cluster Explanations B10.txt";
      questions = true;
    }
  }
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(30);
  text("Choose a test", width/2, height/8-30);
  textSize(15);
  text("2015 Provincial Test", width/8, 3*height/16);
  text("2014 Provincial Test", width/8, 5*height/16);
  text("2014 Regionals Test", width/8, 7*height/16);  
  text("2013 Regionals Test", width/8, 9*height/16);
  text("2013 ICDC Test", width/8, 11*height/16);
  text("2012 Provincial Test", width/8, 13*height/16);
  text("2012 Regionals Test", width/8, 15*height/16);
  text("2011 Provincial Test", 3*width/8, 3*height/16);
  text("2011 Regionals Test", 3*width/8, 5*height/16);
  text("2010 Provincial Test", 3*width/8, 7*height/16);
  if (questions) {
    background(0xff223B83);
    questions();
  }
}
public void financialLiteracy() {
  background(0xff223B83);
  if (mousePressed&&questions==false) {
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 2*height/16 && mouseY < 4*height/16) {
      testTest= "2015 pfl provincials test.txt";
      testAnswers= "2015 pfl provincials actual answers.txt";
      testExplanation = "2015 pfl provincials explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 4*height/16 && mouseY < 6*height/16) {
      testTest= "2014 pfl district test.txt";
      testAnswers= "2014 pfl district answers.txt";
      testExplanation = "2014 pfl district explanations.txt";
      questions = true;
    }
  }
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(30);
  text("Choose a test", width/2, height/8-30);
  textSize(15);
  text("2015 Provincial Test", width/8, 3*height/16);
  text("2014 Provincial Test", width/8, 5*height/16);
  if (questions) {
    background(0xff223B83);
    questions();
  }
}
public void hospitality() {
  background(0xff223B83);
  if (mousePressed&&questions==false) {
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 2*height/16 && mouseY < 4*height/16) {
      testTest= "2015 Business Management Provincial Exam.txt";
      testAnswers= "2015 Business Management Provincial Answers.txt";
      testExplanation = "2015 Business Management Provincial Explainations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 4*height/16 && mouseY < 6*height/16) {
      testTest= "2013 Business Management Provincial Exam.txt";
      testAnswers= "2013 Business Management Provincial Answers.txt";
      testExplanation = "2013 Business Management Provincial Explainations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 6*height/16 && mouseY < 8*height/16) {
      testTest= "2012 Management Admin Provincial Test.txt";
      testAnswers= "2012 Management Admin Provincial Answers.txt";
      testExplanation = "2012 Management Admin Provincial Explaination.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 8*height/16 && mouseY < 10*height/16) {
      testTest= "2011 BMA Cluster Exam.txt";
      testAnswers= "2011 BMA Cluster Answers.txt";
      testExplanation = "2011 BMA Cluster Explainations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 10*height/16 && mouseY < 12*height/16) {
      testTest= "2010 BMA Exam.txt";
      testAnswers= "2010 BMA Answers.txt";
      testExplanation = "2010 BMA Explainations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 12*height/16 && mouseY < 14*height/16) {
      testTest= "2009 BMA Regional Exam.txt";
      testAnswers= "2009 BMA Regional Answers.txt";
      testExplanation = "2009 BMA Regional Explainations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 14*height/16 && mouseY < 16*height/16) {
      testTest= "2009 BLTDM Provincial Exam.txt";
      testAnswers= "2009 BLTDM Provincial Answers.txt";
      testExplanation = "2009 BLTDM Provincial Explainations.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 2*height/16 && mouseY < 4*height/16) {
      testTest= "2008 BLTDM Regional Exam.txt";
      testAnswers= "2008 BLTDM Regional Answers.txt";
      testExplanation = "2008 BLTDM Regional Explainations.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 4*height/16 && mouseY < 6*height/16) {
      testTest= "2007 BLTDM Regional Exam.txt";
      testAnswers= "2007 BLTDM Regional Answers.txt";
      testExplanation = "2007 BLTDM Regional Explainations.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 6*height/16 && mouseY < 8*height/16) {
      testTest= "2005 BLTDM Provincials Exam.txt";
      testAnswers= "2005 BLTDM Provincials Answers.txt";
      testExplanation = "2005 BLTDM Provincials Explainations.txt";
      questions = true;
    }
  }
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(30);
  text("Choose a test", width/2, height/8-30);
  textSize(15);
  text("2015 Provincial Test", width/8, 3*height/16);
  text("2013 Provincial Test", width/8, 5*height/16);
  text("2012 Provincial Test", width/8, 7*height/16);  
  text("2011 Provincial Test", width/8, 9*height/16);
  text("2010 Provincial Test", width/8, 11*height/16);
  text("2009 Regional Test", width/8, 13*height/16);
  text("2009 Provincial Test", width/8, 15*height/16);
  text("2008 Regional Test", 3*width/8, 3*height/16);
  text("2007 Regional Test", 3*width/8, 5*height/16);
  text("2005 Provincial Test", 3*width/8, 7*height/16);
  if (questions) {
    background(0xff223B83);
    questions();
  }
}
public void buisnessAdministrationCore() {
  background(0xff223B83);
  if (mousePressed&&questions==false) {
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 2*height/16 && mouseY < 4*height/16) {
      testTest= "2015 Business Management Provincial Exam.txt";
      testAnswers= "2015 Business Management Provincial Answers.txt";
      testExplanation = "2015 Business Management Provincial Explainations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 4*height/16 && mouseY < 6*height/16) {
      testTest= "2013 Business Management Provincial Exam.txt";
      testAnswers= "2013 Business Management Provincial Answers.txt";
      testExplanation = "2013 Business Management Provincial Explainations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 6*height/16 && mouseY < 8*height/16) {
      testTest= "2012 Management Admin Provincial Test.txt";
      testAnswers= "2012 Management Admin Provincial Answers.txt";
      testExplanation = "2012 Management Admin Provincial Explaination.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 8*height/16 && mouseY < 10*height/16) {
      testTest= "2011 BMA Cluster Exam.txt";
      testAnswers= "2011 BMA Cluster Answers.txt";
      testExplanation = "2011 BMA Cluster Explainations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 10*height/16 && mouseY < 12*height/16) {
      testTest= "2010 BMA Exam.txt";
      testAnswers= "2010 BMA Answers.txt";
      testExplanation = "2010 BMA Explainations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 12*height/16 && mouseY < 14*height/16) {
      testTest= "2009 BMA Regional Exam.txt";
      testAnswers= "2009 BMA Regional Answers.txt";
      testExplanation = "2009 BMA Regional Explainations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 14*height/16 && mouseY < 16*height/16) {
      testTest= "2009 BLTDM Provincial Exam.txt";
      testAnswers= "2009 BLTDM Provincial Answers.txt";
      testExplanation = "2009 BLTDM Provincial Explainations.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 2*height/16 && mouseY < 4*height/16) {
      testTest= "2008 BLTDM Regional Exam.txt";
      testAnswers= "2008 BLTDM Regional Answers.txt";
      testExplanation = "2008 BLTDM Regional Explainations.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 4*height/16 && mouseY < 6*height/16) {
      testTest= "2007 BLTDM Regional Exam.txt";
      testAnswers= "2007 BLTDM Regional Answers.txt";
      testExplanation = "2007 BLTDM Regional Explainations.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 6*height/16 && mouseY < 8*height/16) {
      testTest= "2005 BLTDM Provincials Exam.txt";
      testAnswers= "2005 BLTDM Provincials Answers.txt";
      testExplanation = "2005 BLTDM Provincials Explainations.txt";
      questions = true;
    }
  }
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(30);
  text("Choose a test", width/2, height/8-30);
  textSize(15);
  text("2015 Provincial Test", width/8, 3*height/16);
  text("2013 Provincial Test", width/8, 5*height/16);
  text("2012 Provincial Test", width/8, 7*height/16);
  text("2011 Provincial Test", width/8, 9*height/16);  
  text("2010 Regional Test", width/8, 11*height/16);
  text("2009 Regional Test", width/8, 13*height/16);
  text("2009 Provincial Test", width/8, 15*height/16);
  text("2008 Regional Test", 3*width/8, 3*height/16);
  text("2007 Regional Test", 3*width/8, 5*height/16);
  text("2005 Regional Test", 3*width/8, 7*height/16);

  if (questions) {
    background(0xff223B83);
    questions();
  }
}
public void marketing() {
  background(0xff223B83);
  if (mousePressed&&questions==false) {
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 2*height/16 && mouseY < 4*height/16) {
      testTest= "2015 Marketing Provincials Test.txt";
      testAnswers= "2015 Marketing Provincials Answers.txt";
      testExplanation = "2015 Marketing Provincials Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 4*height/16 && mouseY < 6*height/16) {
      testTest= "2014 Marketing Provincials Test.txt";
      testAnswers= "2014 Marketing Provincials Answers.txt";
      testExplanation = "2014 Marketing Provincials Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 6*height/16 && mouseY < 8*height/16) {
      testTest= "2014 Marketing Regionals Test.txt";
      testAnswers= "2014 Marketing Regionals Answers.txt";
      testExplanation = "2014 Marketing Regionals Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 8*height/16 && mouseY < 10*height/16) {
      testTest= "2013 Marketing Provincials Test.txt";
      testAnswers= "2013 Marketing Provincials Answers.txt";
      testExplanation = "2013 Marketing Provincials Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 10*height/16 && mouseY < 12*height/16) {
      testTest= "2012 Marketing Regionals Test.txt";
      testAnswers= "2012 Marketing Regionals Answers.txt";
      testExplanation = "2012 Marketing Regionals Explanation.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 12*height/16 && mouseY < 14*height/16) {
      testTest= "2011 Marketing Provincials Test.txt";
      testAnswers= "2011 Marketing Provincials Answers.txt";
      testExplanation = "2011 Marketing Provincials Explanations.txt";
      questions = true;
    }
    if (mouseX <3*width/16&& mouseX> width/16&& mouseY > 14*height/16 && mouseY < 16*height/16) {
      testTest= "2009 Marketing Provincials Test.txt";
      testAnswers= "2009 Marketing Provincials Answers.txt";
      testExplanation = "2009 Marketing Provincials Explanation.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 2*height/16 && mouseY < 4*height/16) {
      testTest= "2008 Marketing Provincials Test.txt";
      testAnswers= "2008 Marketing Provincials Answers.txt";
      testExplanation = "2008 Marketing Provincials Explanations.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 4*height/16 && mouseY < 6*height/16) {
      testTest= "2008 Marketing BSM Regionals Test.txt";
      testAnswers= "2008 Marketing BSM Regionals Answers.txt";
      testExplanation = "2008 Marketing BSM Regionals Explanations.txt";
      questions = true;
    }
    if (mouseX <7*width/16&& mouseX> 5*width/16&& mouseY > 6*height/16 && mouseY < 8*height/16) {
      testTest= "2007 SEM Regionals Exam.txt";
      testAnswers= "2007 SEM Regional Answers.txt";
      testExplanation = "2007 SEM Regionals Explanations.txt";
      questions = true;
    }
  }
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(30);
  text("Choose a test", width/2, height/8-30);
  textSize(15);
  text("2015 Provincial Test", width/8, 3*height/16);
  text("2014 Provincial Test", width/8, 5*height/16);
  text("2014 Regional Test", width/8, 7*height/16);  
  text("2013 Provincial Test", width/8, 9*height/16);
  text("2012 Regional Test", width/8, 11*height/16);
  text("2011 Provincial Test", width/8, 13*height/16);
  text("2009 Regional Test", width/8, 15*height/16);
  text("2008 Provincial Test", 3*width/8, 3*height/16);
  text("2008 Regional Test", 3*width/8, 5*height/16);
  text("2007 Regional Test", 3*width/8, 7*height/16);



  if (questions) {
    background(0xff223B83);
    questions();
  }
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--hide-stop", "processing_testing" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
